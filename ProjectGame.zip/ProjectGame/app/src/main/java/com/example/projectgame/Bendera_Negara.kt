package com.example.projectgame

object Bendera_Negara {
    const val TOTAL_QUESTIONS: String = "total_question"
    const val CORRECT_ANSWERS: String = "correct_answers"
    fun getQuestions(): ArrayList<Question>{
        val questionList = ArrayList<Question>()
        val q1 = Question(1, "What country does this flag belong to?",
            R.drawable.bahama, "Ceko", "South Africa", "Bahama", "Djibouti", 3)
        questionList.add(q1)

        val q2 = Question(2, "What country does this flag belong to?",
            R.drawable.grenada, "Grenada", "Honduras", "Dominika", "North Macedonia", 1)
        questionList.add(q2)

        val q3 = Question(3, "What country does this flag belong to?",
            R.drawable.kepulauan_marshall, "Congo Republic", "Cameroon", "Kiribati", "Marshall", 4)
        questionList.add(q3)

        val q4 = Question(4, "What country does this flag belong to?",
            R.drawable.kiribati, "Libya", "Malaysia", "Kiribati", "Djibouti", 3)
        questionList.add(q4)

        val q5 = Question(5, "What country does this flag belong to?",
            R.drawable.mesir, "Nauru", "Egypt", "Rwanda", "Indonesia", 2)
        questionList.add(q5)

        val q6 = Question(6, "What country does this flag belong to?",
            R.drawable.oman, "Yugoslavia", "South Africa", "Vanuatu", "Oman", 4)
        questionList.add(q6)

        val q7 = Question(7, "What country does this flag belong to?",
            R.drawable.panama, "Panama", "Albania", "Bolivia", "Guinea", 1)
        questionList.add(q7)

        val q8 = Question(8, "What country does this flag belong to?",
            R.drawable.siprus, "Guinea", "Haiti", "Cyprus", "India", 3)
        questionList.add(q8)

        val q9 = Question(9, "What country does this flag belong to?",
            R.drawable.uganda, "Iceland", "Canada", "Kyrgyzstan", "Uganda", 4)
        questionList.add(q9)

        val q10 = Question(10, "What country does this flag belong to?",
            R.drawable.zimbabwe, "Cuba", "Zimbabwe", "Lesotho", "Madagascar", 2)
        questionList.add(q10)

        return questionList
    }
}