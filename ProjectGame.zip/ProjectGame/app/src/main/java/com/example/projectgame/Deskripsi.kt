package com.example.projectgame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Deskripsi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deskripsi)
    }
}