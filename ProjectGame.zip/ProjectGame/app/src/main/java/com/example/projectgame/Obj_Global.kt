package com.example.projectgame

object Obj_Global {
    const val TOTAL_QUESTIONS: String = "total_question"
    const val CORRECT_ANSWERS: String = "correct_answers"

    fun getQuestions(): ArrayList<Global>{
        val questiongList = ArrayList<Global>()
        val g1 = Global(1, "Kota Semarang adalah kota yang terkenal dengan bangunan Lawang Sewu, sebenarnya ada berapa pintu pada bangunan tersebut?",
            "428", "528", "629", "928", 4)
        questiongList.add(g1)

        val g2 = Global(2, "Penulisan atau pelafalan kata CINTA sesuai abjad internasional adalah",
            "Charlie-Indonesia-November-Tango-Alpha", "Cheppie-India-November-Tango-Alpha", "Charlie-India-November-Tango-Alpha", "Charlie-Nancy-Taxi-Apple", 3)
        questiongList.add(g2)

        val g3 = Global(3, "Flora Khas dari daerah Nanggroe Aceh Darussalam adalah",
            "Bunga Rafflesia Arnoldi", "Bunga Kenanga", "Bunga Suweng Raksasa", "Bunga Jeumpa", 4)
        questiongList.add(g3)

        val g4 = Global(4, "Siapakah petinju Indonesia pertama yang berhasil meraih gelar juara dunia?",
            "Chris John", "Ellyas Pical", "Nico Thomas", "Wongso Suseno", 2)
        questiongList.add(g4)

        val g5 = Global(5, "Lagu Cik Cik Periuk adalah lagu daerah masyarakat",
            "Kalimantan Barat", "Kalimantan Utara", "Kalimantan Timur", "Kalimantan Tengah", 1)
        questiongList.add(g5)

        val g6 = Global(6, "Salah satu negara yang menjadi anggota organisasi G8 (Group of Eight) adalah",
            "Jepang", "Republik Rakyat Cina", "Australia", "Spanyol", 1)
        questiongList.add(g6)

        val g7 = Global(7, "Penemu Photo Copy pada tahun 1938 adalah",
            "Chester Moon Hall", "Chester Floyd Carlson", "Blasie Pascal", "Count Alessandro", 2)
        questiongList.add(g7)

        val g8 = Global(8, "Negara manakah yang mempunyai garis pantai terpanjang di dunia?",
            "Indonesia", "Jepang", "Kanada", "Republik Rakyat Cina", 3)
        questiongList.add(g8)

        val g9 = Global(9, "Apakah makna kata Kalpataru dalam bahasa Sansekerta?",
            "Pohon Kehidupan", "Pohon Kemuliaan", "Pohon Keabadian", "Pohon Utama", 1)
        questiongList.add(g9)

        val g10 = Global(10, "Planet terdekat dengan matahari adalah",
            "Venus", "Mars", "Neptunus", "Merkurius", 4)
        questiongList.add(g10)

        return questiongList
    }
}